/**
 * This applet demonstrates Q-learning for a particular
 * grid world problem. It isn't designed to be general or reusable.
<p>
 * Copyright (C) 2003-2006  <A HREF="http://www.cs.ubc.ca/spider/poole/">David Poole</A>.
<p>
 * This program gives Q-learning code. The GUI is in <A HREF="Q_GUI.java">Q_GUI.java</A>.  The controller code is at <A HREF="Q_Controller.java">Q_Controller.java</A>, and the environment simulation is at <A HREF="Q_Env.java">Q_Env.java</A>.
<p>
 This program is free software; you can redistribute it and/or
 modify it under the terms of the GNU General Public License
 as published by the Free Software Foundation; either version 2
 of the License, or (at your option) any later version.
<p>
 This program is distributed in the hope that it will be useful,
 but WITHOUT ANY WARRANTY; without even the implied warranty of
 MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 GNU General Public License for more details.
<p>
 You should have received a copy of the GNU General Public License
 along with this program; if not, write to the Free Software
 Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.


 * @author David Poole  poole@cs.ubc.ca
 * @version 0.4 2006-12-04 */

/*
modified by Jesse Hoey 23.09.08 to do Q-learning for the simplest coffee delivery robot
 */
public class Q_Env
{
    public int numberOfSteps=0;
    public double totalReward=0.0;
    public int currS = 0;  // current state 
    public boolean tracing=false;
    public int numvars = 4;
    int fstate[] = new int[numvars];
    int fstatearity[] = new int[]{3,2,4,2};
    public String fstatelabels[][] = new String[4][];
    public String factionlabels[] = new String[4];
    public int totalNumStates=48;  //3*2*4*2
    
    Q_Env()
    {
	doreset();
    }
    /**
     * resets the steps and the reward.
     */
    public void doreset()
    {     
	numberOfSteps=0;
	totalReward=0.0;
	fstatelabels[0] = new String[]{"no","a bit","very"};
	fstatelabels[1] = new String[]{"no","yes"};
	fstatelabels[2] = new String[]{"nada","a bit","a lot","todo"};
	fstatelabels[3] = new String[]{"no","yes"};
	factionlabels[0] = "study";
	factionlabels[1] = "sleep";
	factionlabels[2] = "party";
	factionlabels[3] = "test";
    }

    // factors the state
    // puts the result in fstate
    public void factorState(int st) {
	for (int i=0; i<numvars; i++) {
	    fstate[i] = st%fstatearity[i];
	    st /= fstatearity[i];
	}
    }
    public void factorState(int st, int [] tfstate) {
	for (int i=0; i<numvars; i++) {
	    tfstate[i] = st%fstatearity[i];
	    st /= fstatearity[i];
	}
    }
    public void factorCurrentState() {
	factorState(currS);
    }

    // expand current fstate and return value
    public int expandState() {
	int sfact = 1;
	int st = 0;
	for (int i=0; i<numvars; i++) {
	    st += fstate[i]*sfact;
	    sfact *= fstatearity[i];
	}
	return st;    }
    public int expandState(int [] tfstate) {
	int sfact = 1;
	int st = 0;
	for (int i=0; i<4; i++) {
	    st += tfstate[i]*sfact;
	    sfact *= fstatearity[i];
	}
	return st;
    }


    /**
     * does one step
     *
     * carries out the action
     *
     * @param action  the action that the agent does
     * @return reward received
     */
    public double dostep(int action)  { 
	double reward;

	// factor the state
	int newfstate[] = new int[numvars];

	factorState(currS);
		// copy to newfstate
	for (int i=0; i<numvars; i++) 
	    newfstate[i] = fstate[i];
	

	// fstate[i] is 
	// i=0 studentbot is tired 0=no, 1=a bit, 2=very
	// i=1 studentbot passes test 0=no, 1=yes
	// i=2 studentbot knows 0=nothing, 1= a bit, 2=a lot, 3 = everything
	// i=3 studentbot has a great time 0=no, 1=yes
	// figure out the action
	int rand = (int) (Math.random() * 10); 

	// in all cases, the studentbot starts over if it passes the test
	if (fstate[1]==1) {
	    newfstate[1]=0;
	    newfstate[2]=0;
	}
	// in all cases, the studentbot does not have a good time, unless it parties
	newfstate[3]=0;

	switch (action) {
	case 0:  //study
	    if (rand > 1)  // 20% chance of getting more tired
		newfstate[0] = Math.min(newfstate[0]+1,2);  
	    // 50% of increasing knowledge by 1, but only if not very tired
	    rand = (int) (Math.random() * 10); 
	    
	    if (newfstate[0]<2 && rand > 4) 
		newfstate[2] = Math.min(newfstate[2]+1,3);
	    break;
	case 1: // sleep
	    // becomes not tired
	    newfstate[0] = 0;
	    break;
	case 2: // party
	    // studentbot has a good time if not tired
	    if (newfstate[0]<1)
		newfstate[3] = 1;
	    // student becomes more tired
	    newfstate[0] = Math.min(newfstate[0]+1,2);  
	    // and 50% of forgetting some stuff
	    rand = (int) (Math.random() * 10); 
	    if (rand > 4) 
		newfstate[2] = Math.max(newfstate[2]-1,0);
	    break;
	case 3: // take test
	    // probability student passes test is proportional 
	    // to amount of knowledge, but only if student is not tired
	    rand = (int) (Math.random() * 10); 
	    // student only passes if he knows something and is not very tired
	    if (fstate[2]>0 && fstate[0]<2) {
		if (fstate[2]==1) {
		    // 90% chance of failure if student knows a bit
		    newfstate[1]=(rand>8)?1:0;
		} else if (fstate[2]==2) {
		    //70% chance of failure if student knows a lot
		    newfstate[1]=(rand>6)?1:0;
		} else if (fstate[2]==3) {
		    //10% chance of failure if student knows everything
		    newfstate[1]=(rand>0)?1:0;
		} 
	    }
	    // always become very tired after taking the test
	    newfstate[0]=2;
	    break;
	}

	reward = 0;
	// a big reward if test is passed
	if (newfstate[1]==1) {
	    reward = reward + 20;
	}
	// a smaller reward for partying, 
	// but only if studentbot is was not very tired
	if (newfstate[3]==1) { // && fstate[0]<2) {
	    reward = reward + 2;
	} 

	
	numberOfSteps++;
	totalReward+= reward;

	if (tracing) {
	    for (int i=0;i<numvars;i++) 
		System.out.println("fstate["+i+"]: "+fstate[i]+"  "+newfstate[i]);
	    System.out.println("action taken: "+action);
	    System.out.println("reward received: "+reward);
	    
	}
	// copy to newfstate
	for (int i=0; i<numvars; i++) 
	    fstate[i] = newfstate[i];
	
	currS = expandState();

	return reward;
    }

}
