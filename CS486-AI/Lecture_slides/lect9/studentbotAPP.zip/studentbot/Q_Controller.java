/**
 * This applet demonstrates Q-learning for a particular
 * grid world problem. It isn't designed to be general or reusable.
<p>
 * Copyright (C) 2003-2006  <A HREF="http://www.cs.ubc.ca/spider/poole/">David Poole</A>.
<p>
 * This program gives Q-learning code. The GUI is in <A HREF="Q_GUI.java">Q_GUI.java</A>. The controller code is at <A HREF="Q_Controller.java">Q_Controller.java</A>, and the environment simulation is at <A HREF="Q_Env.java">Q_Env.java</A>.
<p>
 This program is free software; you can redistribute it and/or
 modify it under the terms of the GNU General Public License
 as published by the Free Software Foundation; either version 2
 of the License, or (at your option) any later version.
<p>
 This program is distributed in the hope that it will be useful,
 but WITHOUT ANY WARRANTY; without even the implied warranty of
 MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 GNU General Public License for more details.
<p>
 You should have received a copy of the GNU General Public License
 along with this program; if not, write to the Free Software
 Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.


 * @author David Poole  poole@cs.ubc.ca
 * @version 0.4 2006-12-04 */
/*
modified by Jesse Hoey 23.09.08 to do Q-learning for the simplest coffee delivery robot
 */

public class Q_Controller
{
    /**
       The environment in which the controller operates/
    */
    Q_Env environment;

    /**
       The Q values: Q[state,action]
     */
    public double qvalues[][] = new double[48][4];
    /**
       The number of times the agent has been at (state) and done action
     */
    public int visits[][] = new int[48][4];
    public double discount = 0.9;
    public boolean alphaFixed=true;
    double alpha=0.9;
    public boolean tracing=false;

    Q_Controller(Q_Env env)
    {
	environment = env;
    }

    /**
     * resets the Q-values
     *
     * sets all of the Q-values to initVal, and all of the visit counts to 0
     * @param initVal   the initial value to set all values to
     */
    public void doreset(double initVal)
    {     
	for (int st=0 ; st <48; st++) {
	    for (int i=0; i<4; i++) {
		qvalues[st][i]=initVal;
		visits[st][i]=0;
	    }
	}
    }

    /**
     * does one step
     *
     * carries out the action, and sets the discount and the alpha value
     *
     * @param action  the action that the agent does
     * @param newdiscount  the discount to use
     * @param alphaFieldValue the alpha value to use
     */

    public void dostep(int action, double newdiscount,double alphaFieldValue)  { 
	discount = newdiscount;
	alpha = alphaFieldValue;
	dostep(action);
    }

    /**
     * does one step
     *
     * carries out the action
     *
     * @param action  the action that the agent does
     */
    public void dostep(int action)  { 
        int oldS = environment.currS;
	double reward = environment.dostep(action);

	int newS = environment.currS;

	// update Q values
	double newVal= value(newS);
	double newDatum=reward+discount*newVal;
	visits[oldS][action]++;
	if (!alphaFixed)
	    alpha = 1.0/visits[oldS][action];
		
	if (tracing) {
	    System.out.println("S="+oldS+" A="+action+" R="+reward+" "+newS+" newDatum="+newDatum);
	    System.out.print("     Qold="+qvalues[oldS][action]+" Visits="+visits[oldS][action]+" alpha="+alpha);
	}
	//System.out.println("********************************* alpha is "+alpha);

	qvalues[oldS][action]=
	    (1-alpha) * qvalues[oldS][action] 
	    + alpha*newDatum;
	if (tracing) System.out.println(" Qnew="+qvalues[oldS][action]);
    }

    /**
     * determines the value of a location
     *
     * the value is the maximum, for all actions, of the q-value
     *
     * @param xval the x-coordinate
     * @param yval the y-coordinate
     * @return the value of the (xval,yval) position
     */
    public double value(int st) {
	double val=0;
	for (int i=0; i<4; i++) {
	    if (i==0 || qvalues[st][i] > val) {
		val = qvalues[st][i];
	    }
	}
	return val;
    }

    /**
     * does count number of steps
     *
     * whether each step is greedy or random is determine by greedyProb
     * @param count  the number of steps to do
     * @param greedyProb  the probability that is step is chosen greedily
     */
    public void doSteps(int count, double greedyProb){
	for(int i=0; i<count; i++)
	    {
		double rand = Math.random();
		if (rand<greedyProb)
		    {// act greedily
			double bestVal = 0.0;
			int bestDir = 0;
			int bestAct=0;
			for (int act=0; act<4; act++)
			    {
				if (act == 0 || qvalues[environment.currS][act] > bestVal)
				    {
					bestVal = qvalues[environment.currS][act];
					bestAct = act;
				    }
			    }
			dostep(bestAct);
		    }
		else
		    { // act randomly
			dostep((int) (Math.random() * 4));
		    }
	    }
    }

}
