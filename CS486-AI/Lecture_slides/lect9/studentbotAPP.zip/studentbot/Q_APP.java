import java.text.*;
import java.io.*;
class Q_APP {
    static Q_Env environment = new Q_Env();
    static Q_Controller controller = new Q_Controller(environment);


    public static void printQvalue(int j) {
	
	DecimalFormat df = new DecimalFormat("0.##");
	int tfstate[] = new int[4];
	if (j==environment.currS) 
	    System.out.print("* ");
	System.out.print("\t");
	// factor the state into the variable values
	environment.factorState(j,tfstate);
	// show this state
	for (int i=0; i<4; i++) {
	    System.out.print(environment.fstatelabels[i][tfstate[i]]+"\t");
	}
	int ba=0;
	double bav = controller.qvalues[j][0];
	for (int i=1; i<4; i++) {
	    if (controller.qvalues[j][i]>bav) {
		bav = controller.qvalues[j][i];
		ba = i;
	    }
	}
	
	System.out.print("\t\t\t\t");
	for (int i=0; i<4; i++) {
	    // if its the best state, put it in parentheses
	    if (i==ba) 
		System.out.print("(");
	    System.out.print(df.format(controller.qvalues[j][i]));
	    if (i==ba) 
		System.out.print(")");
	    System.out.print("\t");
	}
	
	System.out.print("\n");
	
    }

    public static void printQvalues_list(int [] thestate)
    {
	
	printQheader();
	int numstates=thestate.length;
	for (int j=0; j < numstates; j++) {
	    printQvalue(thestate[j]);
	}
	    
    }
    public static void printQheader()
    {
	String varnames[] = new String[]{"tired","pass","know","gt"};
	System.out.println("\tstate:\t\t\t\t\t\t\t\t\tactions and q values:");
	System.out.println("\t* = current state\t\t\t\t\t\t\t (...) = max value");

	System.out.print("\t");
	for (int i=0; i<4; i++) {
	    System.out.print(varnames[i]+"\t");
	}
	String actnames[] = new String[]{"study","sleep","party","taketest"};
	System.out.print("\t\t\t\t");
	for (int i=0; i<4; i++) {
	    System.out.print(actnames[i]+"\t");
	}
	// a new line
	System.out.print("\n--------------------------------------------------------------------------------------------------------------\n");
    }
    public static void printQvalues()
    {
	DecimalFormat df = new DecimalFormat("0.##");
	// draw the names of the variables
	// would be better if this was done automatically
	
	//System.out.println("tired:\t\t 0=no,\t\t 1=a bit,\t  2=very");
	//System.out.println("pass test:\t 0=no,\t\t 1=yes");
	//System.out.println("knowledge:\t 0=nothing,\t 1=a bit,\t 2=a lot,\t 3=everything");
	//System.out.println("good time:\t 0=no,\t\t 1=yes");
	printQheader();
	// print out all states
	int tfstate[] = new int[4];
	
	for (int j=0; j<environment.totalNumStates; j++) {
	    printQvalue(j);
	}    
    }

    public static void main(String[] args) {
	double greedypct=0.8;
	int numsteps=400;
	int action=0;
	int savestate=0;
	int [] twostates = new int[2];
	InputStreamReader cin = new InputStreamReader(System.in);
	
	try {
	    BufferedReader in = new BufferedReader(new InputStreamReader(System.in));
	    String str = "";
	    Boolean unrec;
	    while (str != null) {
		System.out.print("enter command (show/step/action/reset/stop):  ");
		str = in.readLine();
		unrec=true;
		if (str.equalsIgnoreCase("step")) {
		    System.out.print("number of steps: ");
		    str = in.readLine();
		    numsteps = Integer.parseInt(str);
		    controller.doSteps(numsteps,greedypct);	
		}  else if (str.equalsIgnoreCase("action")) {
		    action=-1;
		    while (action<0) {
			System.out.print("action to take from: ");
			for (int j=0;j<environment.factionlabels.length; j++) {
			    System.out.print(environment.factionlabels[j]);
			    if (j<environment.factionlabels.length-1) {
				System.out.print("/");
			    }
			}
			System.out.print(": ");
			str = in.readLine();
			for (int j=0;j<environment.factionlabels.length; j++) {
			    if (str.equalsIgnoreCase(environment.factionlabels[j]))
				action = j;
			}
		    }
		    //action = Integer.parseInt(str);
		    savestate=environment.currS;
		    controller.dostep(action);
		    System.out.print("\n Pre-action and post-action state:\n");
		    twostates[0]=savestate;
		    twostates[1]=environment.currS;
		    printQvalues_list(twostates);
		    //printQvalue(environment.currS);
		} else if (str.equalsIgnoreCase("show")) {
		    unrec=false;
		} else if (str.equalsIgnoreCase("reset")) {
		    environment.doreset();
		    controller.doreset(0.0);
		    unrec=false;
		} else if (str.equalsIgnoreCase("stop")) {
		    str=null;
		    unrec=false;
		} else {
		    System.out.println("unrecognized command");
		    unrec=true;
		}
		if (!unrec) {
		    printQvalues();
		    System.out.println("Number of steps: "+environment.numberOfSteps);
		    System.out.println("Total reward received: "+environment.totalReward);
		}
	    }
	} catch (IOException e) {
	}
    }
}
